	<div class="col-12 bg-dark text-center text-white">
		<br>
		<h4>&copy; <span style="font-family: 'Nosifer', cursive;">POSTS</span> 2020</h4>
		<br>
	</div>



</body>
</html>